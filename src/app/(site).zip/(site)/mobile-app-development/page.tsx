import MobileAppDevelopmentPage from "@/components/mobile-app-development/MobileAppDevelopmentPage";
import { enterpriseMobileAppContent } from "@/data/mobile-app-development";

export default function MobileAppDevelopmentRootPage() {
  return <MobileAppDevelopmentPage data={enterpriseMobileAppContent} />;
}
