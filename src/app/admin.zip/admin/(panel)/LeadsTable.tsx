"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { Mail, MapPin, Satellite, Globe, ExternalLink, Trash2, Package as PackageIcon, Copy, Check, Forward } from "lucide-react";
import type { Lead } from "@/server/contact/queries";
import { categoryForSource, labelForSource, LEAD_STATUSES } from "@/server/contact/lead-sources";
import { trashLeadAction, updateLeadStatusAction } from "@/server/contact/lead-actions";
import ConfirmButton from "./ConfirmButton";

/**
 * A lead's category tags. Leads from the quote flow are categorised by the
 * package(s) the client selected; everything else falls back to the broad,
 * source-based category. A lead can belong to several package categories.
 */
function leadCategoryTags(lead: Lead): string[] {
  if (lead.packageCategory) {
    const tags = lead.packageCategory.split(",").map((s) => s.trim()).filter(Boolean);
    if (tags.length) return tags;
  }
  return [categoryForSource(lead.source)];
}

/** A Google Maps link for a lead's location (coords preferred, else the label). */
function mapsUrl(loc: Lead["location"]): string | null {
  if (!loc) return null;
  if (typeof loc.lat === "number" && typeof loc.lng === "number") {
    return `https://www.google.com/maps?q=${loc.lat},${loc.lng}`;
  }
  if (loc.label) return `https://www.google.com/maps/search/${encodeURIComponent(loc.label)}`;
  return null;
}

/** Subject line used when forwarding a lead's enquiry. */
function forwardSubject(lead: Lead): string {
  return `Fwd: Enquiry from ${lead.name}`;
}

/**
 * Deterministic date format for the forwarded body. Uses an explicit locale +
 * timezone so the server and client render the exact same string — otherwise
 * the value ends up in the Link `href` and causes a hydration mismatch.
 */
function formatReceived(iso: string): string {
  return new Date(iso).toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Kolkata",
  });
}

/**
 * A quotable, forward-ready version of the lead's message with the original
 * sender's details attached — the kind of block you'd paste into an email.
 */
function forwardBody(lead: Lead): string {
  const lines: (string | null)[] = [
    "---------- Forwarded message ----------",
    `From: ${lead.name} <${lead.email}>`,
    lead.phone ? `Phone: ${lead.phone}` : null,
    lead.company ? `Company: ${lead.company}` : null,
    `Received: ${formatReceived(lead.created_at)}`,
    `Source: ${labelForSource(lead.source)}`,
    lead.budget ? `Budget: ${lead.budget}` : null,
    "",
    lead.message || "(no message)",
  ];
  return lines.filter((l) => l !== null).join("\n");
}

/** Link to the Mail panel, pre-filled with the forwarded message (no recipient). */
function forwardMailHref(lead: Lead): string {
  const params = new URLSearchParams({
    subject: forwardSubject(lead),
    body: forwardBody(lead),
  });
  return `/admin/mail?${params.toString()}`;
}

/**
 * Copy the message + Forward it via the Mail panel. `text` is what lands on the
 * clipboard (defaults to the forward-ready block).
 */
function ForwardActions({ lead, text }: { lead: Lead; text?: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(text ?? forwardBody(lead));
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard blocked (e.g. insecure context) — silently ignore.
    }
  };

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={copy}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium text-heading transition-colors hover:border-primary/30 hover:bg-primary/5"
      >
        {copied ? <Check size={15} className="text-emerald-600" /> : <Copy size={15} />}
        {copied ? "Copied" : "Copy message"}
      </button>
      <Link
        href={forwardMailHref(lead)}
        onClick={(e) => e.stopPropagation()}
        className="inline-flex items-center gap-1.5 rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/10"
      >
        <Forward size={15} aria-hidden="true" />
        Forward
      </Link>
    </div>
  );
}

export default function LeadsTable({ leads }: { leads: Lead[] }) {
  const [filter, setFilter] = useState<string>("all");
  const [activeLead, setActiveLead] = useState<Lead | null>(null);
  const [deleted, setDeleted] = useState<Set<string>>(new Set());

  // Hide optimistically-removed rows; revalidation drops them for good.
  const visibleLeads = useMemo(() => leads.filter((l) => !deleted.has(l.id)), [leads, deleted]);
  const remove = (id: string) => {
    setDeleted((prev) => new Set(prev).add(id));
    setActiveLead((cur) => (cur?.id === id ? null : cur));
  };

  // Tally leads per category tag (package-aware).
  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const lead of visibleLeads) {
      for (const tag of leadCategoryTags(lead)) map.set(tag, (map.get(tag) ?? 0) + 1);
    }
    return map;
  }, [visibleLeads]);

  // Most-common categories first, then alphabetical.
  const categories = useMemo(
    () => [...counts.keys()].sort((a, b) => (counts.get(b)! - counts.get(a)!) || a.localeCompare(b)),
    [counts]
  );

  const filtered = useMemo(
    () =>
      filter === "all"
        ? visibleLeads
        : visibleLeads.filter((l) => leadCategoryTags(l).includes(filter)),
    [visibleLeads, filter]
  );

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <FilterButton label="All" count={visibleLeads.length} active={filter === "all"} onClick={() => setFilter("all")} />
        {categories.map((cat) => (
          <FilterButton
            key={cat}
            label={cat}
            count={counts.get(cat) ?? 0}
            active={filter === cat}
            onClick={() => setFilter(cat)}
          />
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="rounded-md border border-border bg-card p-6 text-center text-muted-foreground">
          No leads in this category.
        </p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-border bg-card shadow-sm">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="border-b border-border bg-gradient-to-r from-primary/[0.08] to-accent/[0.06] text-left text-xs font-semibold uppercase tracking-wide text-primary">
                <Th>Received</Th>
                <Th>Category</Th>
                <Th>Contact</Th>
                <Th>Package</Th>
                <Th>Budget</Th>
                <Th>Location</Th>
                <Th>Message</Th>
                <Th>Status</Th>
                <Th>Actions</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((lead) => (
                <tr
                  key={lead.id}
                  className="cursor-pointer border-b border-border/60 align-top transition-colors hover:bg-primary/[0.035]"
                  onClick={() => setActiveLead(lead)}
                >
                  <Td className="whitespace-nowrap text-muted-foreground">
                    <ReceivedAt iso={lead.created_at} />
                  </Td>
                  <Td className="whitespace-nowrap">
                    <div className="flex flex-wrap gap-1">
                      {leadCategoryTags(lead).map((tag) => (
                        <span key={tag} className="rounded-full border border-border px-2 py-0.5 text-xs">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{labelForSource(lead.source)}</p>
                  </Td>
                  <Td>
                    <p className="font-medium text-heading">{lead.name}</p>
                    <a
                      href={`mailto:${lead.email}`}
                      onClick={(e) => e.stopPropagation()}
                      className="block text-primary hover:underline"
                    >
                      {lead.email}
                    </a>
                    {lead.phone ? (
                      <a
                        href={`tel:${lead.phone}`}
                        onClick={(e) => e.stopPropagation()}
                        className="block whitespace-nowrap text-muted-foreground hover:text-primary"
                      >
                        {lead.phone}
                      </a>
                    ) : null}
                    {lead.company ? <p className="text-xs text-muted-foreground">{lead.company}</p> : null}
                  </Td>
                  <Td className="max-w-[12rem]">
                    {lead.packageCategory ? (
                      <span className="inline-flex items-center gap-1 text-heading">
                        <PackageIcon size={13} className="shrink-0 text-muted-foreground" />
                        {lead.packageCategory}
                      </span>
                    ) : (
                      "—"
                    )}
                  </Td>
                  <Td className="whitespace-nowrap">{lead.budget ?? "—"}</Td>
                  <Td className="max-w-[13rem]">
                    <LocationCell location={lead.location} />
                  </Td>
                  <Td className="max-w-xs">
                    {lead.message ? (
                      <span className="line-clamp-2 text-heading">{lead.message}</span>
                    ) : (
                      "—"
                    )}
                  </Td>
                  <Td>
                    <StatusSelect lead={lead} />
                  </Td>
                  <Td>
                    <div className="flex items-center gap-1.5">
                      <Link
                        href={forwardMailHref(lead)}
                        onClick={(e) => e.stopPropagation()}
                        title="Forward via Mail"
                        aria-label="Forward via Mail"
                        className="inline-flex items-center justify-center rounded-md border border-primary/30 bg-primary/5 p-2 text-primary transition-colors hover:bg-primary/10"
                      >
                        <Forward size={14} aria-hidden="true" />
                      </Link>
                      <TrashButton leadId={lead.id} onDone={() => remove(lead.id)} />
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeLead && (
        <LeadDetailModal
          lead={activeLead}
          onClose={() => setActiveLead(null)}
          onDeleted={() => remove(activeLead.id)}
        />
      )}
    </>
  );
}

/** Moves a lead to the Bin after an in-app confirmation. */
function TrashButton({ leadId, onDone }: { leadId: string; onDone: () => void }) {
  return (
    <ConfirmButton
      label="Delete"
      icon={<Trash2 size={13} />}
      variant="danger"
      title="Move to Bin?"
      message="This lead will be moved to the Bin. You can restore it or delete it permanently from there."
      confirmLabel="Move to Bin"
      action={() => trashLeadAction(leadId)}
      onDone={onDone}
    />
  );
}

/** Compact location display for the table cell. */
function LocationCell({ location }: { location: Lead["location"] }) {
  if (!location) return <span className="text-muted-foreground">—</span>;
  const url = mapsUrl(location);
  const Icon = location.source === "gps" ? Satellite : Globe;
  const inner = (
    <span className="inline-flex items-start gap-1 text-heading">
      <Icon size={13} className="mt-0.5 shrink-0 text-muted-foreground" />
      <span>
        {location.label || "Unknown"}
        <span className="ml-1 text-[10px] uppercase tracking-wide text-muted-foreground">
          {location.source}
        </span>
      </span>
    </span>
  );
  return url ? (
    <a href={url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="hover:text-primary hover:underline">
      {inner}
    </a>
  ) : (
    inner
  );
}

// Rich detail modal — shows every field we hold on a lead. Closes on backdrop
// click or Escape.
function LeadDetailModal({
  lead,
  onClose,
  onDeleted,
}: {
  lead: Lead;
  onClose: () => void;
  onDeleted: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const loc = lead.location;
  const url = mapsUrl(loc);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-lg border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-heading">{lead.name}</h2>
            <p className="text-xs text-muted-foreground">
              {labelForSource(lead.source)} · <ReceivedAt iso={lead.created_at} />
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-heading"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 border-b border-border px-5 py-4 text-sm">
          <Row label="Email">
            <a href={`mailto:${lead.email}`} className="text-primary hover:underline">
              {lead.email}
            </a>
          </Row>
          {lead.phone && (
            <Row label="Phone">
              <a href={`tel:${lead.phone}`} className="text-primary hover:underline">
                {lead.phone}
              </a>
            </Row>
          )}
          {lead.company && <Row label="Company">{lead.company}</Row>}
          {lead.packageCategory && <Row label="Package">{lead.packageCategory}</Row>}
          {lead.budget && <Row label="Budget">{lead.budget}</Row>}
          <Row label="Category">{leadCategoryTags(lead).join(", ")}</Row>
          <Row label="Status"><StatusSelect lead={lead} /></Row>
        </dl>

        {loc && (
          <div className="border-b border-border px-5 py-4">
            <p className="mb-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              <MapPin size={13} /> Location
              <span className="rounded-full border border-border px-1.5 py-0.5 text-[10px] normal-case">
                {loc.source === "gps" ? "Precise (GPS)" : "Approx. (IP)"}
              </span>
            </p>
            <p className="text-sm font-medium text-heading">{loc.label || "Unknown"}</p>
            <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-xs text-muted-foreground">
              {typeof loc.lat === "number" && typeof loc.lng === "number" && (
                <Row label="Coordinates">
                  {loc.lat.toFixed(5)}, {loc.lng.toFixed(5)}
                </Row>
              )}
              {typeof loc.accuracy === "number" && <Row label="Accuracy">±{Math.round(loc.accuracy)} m</Row>}
              {loc.ip && <Row label="IP">{loc.ip}</Row>}
              {loc.isp && <Row label="ISP">{loc.isp}</Row>}
            </dl>
            {url && (
              <a
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
              >
                <ExternalLink size={12} /> Open in Google Maps
              </a>
            )}
          </div>
        )}

        <div className="px-5 py-4">
          <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">Message</p>
          <p className="mb-3 whitespace-pre-wrap break-words text-sm leading-relaxed text-heading">
            {lead.message || "—"}
          </p>
          <ForwardActions lead={lead} text={lead.message ?? ""} />
        </div>

        <div className="flex items-center justify-between border-t border-border px-5 py-3">
          <TrashButton leadId={lead.id} onDone={onDeleted} />
          <Link
            href={`/admin/mail?to=${encodeURIComponent(lead.email)}`}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground"
          >
            <Mail size={15} aria-hidden="true" />
            Compose email
          </Link>
        </div>
      </div>
    </div>
  );
}

// Colour per status for the dropdown pill.
const STATUS_STYLES: Record<string, string> = {
  new: "border-sky-300 bg-sky-50 text-sky-700",
  contacted: "border-amber-300 bg-amber-50 text-amber-700",
  "in-progress": "border-violet-300 bg-violet-50 text-violet-700",
  converted: "border-emerald-300 bg-emerald-50 text-emerald-700",
  disqualified: "border-rose-300 bg-rose-50 text-rose-700",
};

/** Inline status editor — updates the lead's status via a server action. */
function StatusSelect({ lead }: { lead: Lead }) {
  const [status, setStatus] = useState(lead.status);
  const [syncedStatus, setSyncedStatus] = useState(lead.status);
  const [pending, startTransition] = useTransition();

  // Re-sync if the server sends a newer value (after revalidation) — adjust
  // state during render rather than in an effect.
  if (lead.status !== syncedStatus) {
    setSyncedStatus(lead.status);
    setStatus(lead.status);
  }

  const onChange = (value: string) => {
    const prev = status;
    setStatus(value); // optimistic
    startTransition(async () => {
      const res = await updateLeadStatusAction(lead.id, value);
      if (!res.ok) setStatus(prev); // revert on failure
    });
  };

  const known = LEAD_STATUSES.some((s) => s.value === status);

  return (
    <select
      value={status}
      disabled={pending}
      onClick={(e) => e.stopPropagation()}
      onChange={(e) => onChange(e.target.value)}
      title="Update status"
      className={`cursor-pointer rounded-full border px-2 py-1 text-xs font-medium capitalize outline-none transition-colors disabled:opacity-60 ${
        STATUS_STYLES[status] ?? "border-border bg-card text-heading"
      }`}
    >
      {!known ? <option value={status}>{status}</option> : null}
      {LEAD_STATUSES.map((s) => (
        <option key={s.value} value={s.value}>
          {s.label}
        </option>
      ))}
    </select>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="break-words text-heading">{children}</dd>
    </>
  );
}

function FilterButton({
  label,
  count,
  active,
  onClick,
}: {
  label: string;
  count: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-3 py-1 text-sm transition-all ${
        active
          ? "border-transparent bg-gradient-to-r from-primary to-accent text-white shadow-md shadow-primary/20"
          : "border-border bg-card text-heading hover:border-primary/30 hover:bg-primary/5"
      }`}
    >
      {label}
      <span className={`ml-1.5 text-xs ${active ? "opacity-90" : "text-muted-foreground"}`}>{count}</span>
    </button>
  );
}

// Locale-formatted timestamp. `suppressHydrationWarning` covers the expected
// server/client difference in locale + timezone formatting.
function ReceivedAt({ iso }: { iso: string }) {
  return <span suppressHydrationWarning>{new Date(iso).toLocaleString()}</span>;
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="px-4 py-3 font-medium">{children}</th>;
}

function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-3 text-heading ${className}`}>{children}</td>;
}
